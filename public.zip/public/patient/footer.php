   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
					<div class="col-md-4" id="contact">
					<p>Category</p>
					<ul>
						<li><a href="#">SignUp as a Donor</a></li>
						<li><a href="#">Contact with Doctors</a></li>
						
					</ul>
					</div>
					<div class="col-md-4">
						<p>Contact</p>
						<p>name here <br>
							details</p>
						
					</div>
					<div class="col-md-4 share_img">
					<p>Link with</p>
						<a href=""><img src="img/fb.png" alt=""></a>
						<a href=""><img src="img/feed.png" alt=""></a>
						<a href=""><img src="img/twiter.png" alt=""></a>
					</div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 

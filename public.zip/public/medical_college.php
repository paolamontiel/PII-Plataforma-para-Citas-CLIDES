<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="form-group mc">
		<h2 class="text-center" style="background-color:#272327;color: #fff;">Public Medical College</h2>

                              <table cellpadding="10" cellspacing="10" class="table table-hover">   

                                  <tr>
                                      <th>No.</th><th>Name</th><th>Acronym</th><th>Established</th><th>Location</th><th>website</td>
                                  </tr>
                                  
                              </table>
	</div>
	

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
		<!-- footer section Ends--> 


	
	</div><!--  containerFluid Ends -->



	<script src="js/bootstrap.min.js"></script>
	
</body>
</html>